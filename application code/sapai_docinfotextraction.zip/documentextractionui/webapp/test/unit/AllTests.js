sap.ui.define([
	"com/solex/documentextractionui/test/unit/controller/docinfoextraction.controller"
], function () {
	"use strict";
});